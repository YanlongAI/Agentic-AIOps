#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""节点负载查询：集群预检 + 节点 CPU/内存指标。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import check_cluster, emit, get_node_metrics, list_node_names


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="K8s 节点负载查询")
    parser.add_argument("action", choices=["query"])
    parser.add_argument("--node-name", default="all", help="节点名，逗号分隔或 all")
    parser.add_argument("--threshold", type=int, default=70, help="高负载阈值（%）")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    ok, msg = check_cluster()
    if not ok:
        emit(1, msg)

    nodes = list_node_names() if args.node_name == "all" else [n.strip() for n in args.node_name.split(",") if n.strip()]
    if not nodes:
        emit(1, "未找到可用节点")

    metrics_list = [get_node_metrics(node) for node in nodes]
    high_load_nodes = [
        item for item in metrics_list
        if item.get("ready") and not item.get("error")
        and (item.get("cpu_percent", 0) > args.threshold or item.get("mem_percent", 0) > args.threshold)
    ]

    emit(0, msg, {
        "node_metrics_list": metrics_list,
        "high_load_node_list": high_load_nodes,
        "high_load_node_count": len(high_load_nodes),
        "threshold": args.threshold,
    })


if __name__ == "__main__":
    main()
