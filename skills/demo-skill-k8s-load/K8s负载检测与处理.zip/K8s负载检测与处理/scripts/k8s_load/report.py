#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""排障报告：generate 生成 Markdown / push 推送飞书。"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from urllib import error, request

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import check_cluster, emit, get_node_metrics, get_pods_on_node, list_node_names


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="K8s 高负载排障报告")
    parser.add_argument("action", choices=["generate", "push"])
    parser.add_argument("--node-name", default="all")
    parser.add_argument("--threshold", type=int, default=70)
    parser.add_argument("--report-path", default="./reports")
    parser.add_argument("--webhook-url", default="")
    return parser.parse_args()


def collect_snapshot(node_name: str, threshold: int) -> dict:
    nodes = list_node_names() if node_name == "all" else [n.strip() for n in node_name.split(",")]
    node_metrics = [get_node_metrics(n) for n in nodes]
    high_nodes = [
        n for n in node_metrics
        if n.get("ready") and not n.get("error")
        and (n.get("cpu_percent", 0) > threshold or n.get("mem_percent", 0) > threshold)
    ]
    pod_rows = []
    for item in high_nodes:
        for pod in get_pods_on_node(item["node_name"], top_n=5):
            pod["node_name"] = item["node_name"]
            pod_rows.append(pod)
    return {
        "node_metrics": node_metrics,
        "high_load_nodes": high_nodes,
        "top_pods": pod_rows[:10],
        "threshold": threshold,
    }


def build_markdown(snapshot: dict, node_label: str) -> str:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "# K8s 节点高负载排障报告",
        "",
        f"- 生成时间：{now}",
        f"- 统计节点：{node_label}",
        f"- 高负载阈值：{snapshot['threshold']}%",
        f"- 高负载节点数：{len(snapshot['high_load_nodes'])}",
        "",
        "## 节点负载",
        "",
    ]
    for node in snapshot["node_metrics"]:
        if node.get("error"):
            lines.append(f"- **{node['node_name']}**：{node['error']}")
            continue
        lines.append(
            f"- **{node['node_name']}**：CPU {node.get('cpu_percent', '-')}%，"
            f"内存 {node.get('mem_percent', '-')}%，高负载={node.get('high_load', False)}"
        )

    lines.extend(["", "## TOP 高资源 Pod", ""])
    if not snapshot["top_pods"]:
        lines.append("无")
    else:
        for idx, pod in enumerate(snapshot["top_pods"], 1):
            lines.append(
                f"{idx}. `{pod['namespace']}/{pod['pod_name']}` @ {pod.get('node_name', '-')} "
                f"CPU={pod['cpu']} MEM={pod['mem']}"
            )
    lines.append("")
    return "\n".join(lines)


def push_feishu(webhook_url: str, content: str) -> tuple[bool, str]:
    payload = json.dumps({
        "msg_type": "text",
        "content": {"text": content[:4000]},
    }).encode("utf-8")
    req = request.Request(
        webhook_url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=15) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            return True, body
    except error.HTTPError as exc:
        return False, f"HTTP {exc.code}: {exc.read().decode('utf-8', errors='replace')}"
    except Exception as exc:
        return False, str(exc)


def main() -> None:
    args = parse_args()
    ok, msg = check_cluster()
    if not ok:
        emit(1, msg)

    snapshot = collect_snapshot(args.node_name, args.threshold)
    markdown = build_markdown(snapshot, args.node_name)

    if args.action == "generate":
        os.makedirs(args.report_path, exist_ok=True)
        filename = f"k8s-load-report-{datetime.now().strftime('%Y%m%d%H%M%S')}.md"
        full_path = os.path.join(args.report_path, filename)
        with open(full_path, "w", encoding="utf-8") as handle:
            handle.write(markdown)
        emit(0, "报告已生成", {
            "report_path": full_path,
            "size_bytes": os.path.getsize(full_path),
            "high_load_node_count": len(snapshot["high_load_nodes"]),
            "summary": markdown.splitlines()[:8],
        })

    if not args.webhook_url:
        emit(1, "push 需通过 extra_args 传入 webhook-url")

    success, detail = push_feishu(args.webhook_url, markdown)
    if not success:
        emit(1, f"飞书推送失败: {detail}")
    emit(0, "飞书推送成功", {"detail": detail})


if __name__ == "__main__":
    main()
