#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""高负载 Pod 驱逐：preview 预览 / execute 执行（需 --confirm）。"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import (
    check_cluster,
    emit,
    find_low_load_node,
    get_node_metrics,
    get_pods_on_node,
    is_core_component,
    run_kubectl,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="K8s Pod 驱逐")
    parser.add_argument("action", choices=["preview", "execute"])
    parser.add_argument("--pod-name", required=True)
    parser.add_argument("--namespace", default="default")
    parser.add_argument("--target-node", default="", help="建议调度目标节点（可选）")
    parser.add_argument("--confirm", default="false", help="execute 时传 true")
    return parser.parse_args()


def get_pod_node(namespace: str, pod_name: str) -> str | None:
    code, out, _ = run_kubectl([
        "get", "pod", pod_name, "-n", namespace,
        "-o", "jsonpath={.spec.nodeName}",
    ])
    return out.strip() if code == 0 and out.strip() else None


def pod_is_running(namespace: str, pod_name: str) -> tuple[bool, str]:
    code, out, err = run_kubectl([
        "get", "pod", pod_name, "-n", namespace,
        "-o", "jsonpath={.status.phase}",
    ])
    if code != 0:
        return False, err or "Pod 不存在"
    phase = out.strip()
    if phase != "Running":
        return False, f"Pod 状态为 {phase}，无需驱逐"
    return True, "Running"


def main() -> None:
    args = parse_args()
    ok, msg = check_cluster()
    if not ok:
        emit(1, msg)

    if is_core_component(args.namespace, args.pod_name):
        emit(1, "禁止驱逐集群核心组件 Pod")

    running, status_msg = pod_is_running(args.namespace, args.pod_name)
    if not running:
        emit(1, status_msg)

    source_node = get_pod_node(args.namespace, args.pod_name)
    target_node = args.target_node or (find_low_load_node(exclude=source_node) if source_node else find_low_load_node())
    if not target_node:
        emit(1, "无可用低负载节点（CPU/内存均 <50%）")

    preview = {
        "pod_name": args.pod_name,
        "namespace": args.namespace,
        "source_node": source_node,
        "suggest_target_node": target_node,
        "action": "kubectl delete pod（由控制器重建，不修改 nodeSelector）",
    }

    if args.action == "preview":
        emit(0, "驱逐预览", preview)

    if str(args.confirm).lower() not in ("true", "1", "yes"):
        emit(1, "execute 必须携带 --confirm true，请先 preview 并获人工确认")

    before = get_node_metrics(source_node) if source_node else {}
    code, _, err = run_kubectl([
        "delete", "pod", args.pod_name, "-n", args.namespace, "--grace-period=30",
    ])
    if code != 0:
        emit(1, err or "Pod 驱逐失败")

    time.sleep(6)
    after = get_node_metrics(source_node) if source_node else {}
    emit(0, "Pod 已驱逐，等待控制器重建", {
        **preview,
        "node_load_before": before,
        "node_load_after": after,
    })


if __name__ == "__main__":
    main()
