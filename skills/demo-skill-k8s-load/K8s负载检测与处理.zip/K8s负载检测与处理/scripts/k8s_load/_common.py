# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""K8s 负载检测共享工具：SSH 登录 kubectl 所在 Linux，远程执行 kubectl。"""

from __future__ import annotations

import io
import json
import os
import re
import shlex
import sys
from dataclasses import dataclass
from typing import Any

import paramiko

CORE_NAMESPACES = frozenset({"kube-system", "kube-public", "kube-node-lease"})
CORE_KEYWORDS = (
    "kube-apiserver",
    "etcd",
    "calico",
    "coredns",
    "kube-controller",
    "kube-scheduler",
    "kube-proxy",
)
DEFAULT_TIMEOUT = 30


@dataclass
class SshTarget:
    host: str
    port: int
    username: str
    password: str | None = None
    private_key: str | None = None
    remote_kubeconfig: str = ""


def emit(code: int, msg: str, data: dict[str, Any] | None = None) -> None:
    """输出统一 JSON 并退出。"""
    payload = {"code": code, "msg": msg, "data": data or {}}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    sys.exit(0 if code == 0 else 1)


def load_ssh_target() -> SshTarget:
    """从平台注入的环境变量读取 SSH 跳板信息。"""
    host = os.environ.get("KUBE_SSH_HOST", "").strip()
    if not host:
        emit(1, "缺少 KUBE_SSH_HOST，请绑定 kubectl 所在 Linux 实例并由平台注入 SSH 凭证")
    return SshTarget(
        host=host,
        port=int(os.environ.get("KUBE_SSH_PORT") or 22),
        username=os.environ.get("KUBE_SSH_USER") or "root",
        password=os.environ.get("KUBE_SSH_PASSWORD") or None,
        private_key=os.environ.get("KUBE_SSH_PRIVATE_KEY") or None,
        remote_kubeconfig=os.environ.get("KUBE_REMOTE_KUBECONFIG", "").strip(),
    )


def _connect_ssh(target: SshTarget) -> paramiko.SSHClient:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    pkey = None
    if target.private_key:
        try:
            pkey = paramiko.RSAKey.from_private_key(io.StringIO(target.private_key))
        except paramiko.SSHException:
            pkey = paramiko.Ed25519Key.from_private_key(io.StringIO(target.private_key))
    client.connect(
        hostname=target.host,
        port=target.port,
        username=target.username,
        password=target.password if not pkey else None,
        pkey=pkey,
        timeout=30,
        banner_timeout=30,
    )
    transport = client.get_transport()
    if transport:
        transport.set_keepalive(30)
    return client


def _build_remote_kubectl_command(args: list[str], remote_kubeconfig: str) -> str:
    kubectl = "kubectl " + " ".join(shlex.quote(part) for part in args)
    if remote_kubeconfig:
        return f"KUBECONFIG={shlex.quote(remote_kubeconfig)} {kubectl}"
    return kubectl


def run_kubectl(args: list[str], timeout: int = DEFAULT_TIMEOUT) -> tuple[int, str, str]:
    """通过 SSH 在远程 Linux 执行 kubectl。"""
    target = load_ssh_target()
    command = _build_remote_kubectl_command(args, target.remote_kubeconfig)
    client = _connect_ssh(target)
    try:
        _, stdout, stderr = client.exec_command(command, timeout=timeout)
        exit_code = stdout.channel.recv_exit_status()
        out = stdout.read().decode("utf-8", errors="replace").strip()
        err = stderr.read().decode("utf-8", errors="replace").strip()
        return exit_code, out, err
    finally:
        client.close()


def check_cluster() -> tuple[bool, str]:
    """校验 SSH 连通性、远程 kubectl 与 metrics-server。"""
    target = load_ssh_target()
    client = _connect_ssh(target)
    try:
        _, stdout, stderr = client.exec_command("command -v kubectl", timeout=10)
        if stdout.channel.recv_exit_status() != 0:
            return False, stderr.read().decode("utf-8", errors="replace") or "远程未安装 kubectl"
    finally:
        client.close()

    code, _, err = run_kubectl(["get", "nodes", "-o", "name"], timeout=20)
    if code != 0:
        return False, err or "远程 kubectl 无法连接集群，请检查跳板机 kubeconfig"
    code, _, err = run_kubectl(["top", "nodes", "--no-headers"], timeout=20)
    if code != 0:
        return False, err or "metrics-server 不可用，无法采集节点负载"
    return True, f"SSH {target.host} 远程 kubectl 连通正常"


def list_node_names() -> list[str]:
    code, out, _ = run_kubectl(["get", "nodes", "-o", "jsonpath={.items[*].metadata.name}"])
    if code != 0 or not out:
        return []
    return out.split()


def is_node_ready(node_name: str) -> bool:
    code, out, _ = run_kubectl([
        "get", "node", node_name,
        "-o", "jsonpath={.status.conditions[?(@.type=='Ready')].status}",
    ])
    return code == 0 and out.strip() == "True"


def parse_percent(value: str) -> float:
    return float(value.rstrip("%"))


def parse_cpu_milli(value: str) -> int:
    value = value.strip()
    if value.endswith("m"):
        return int(value[:-1])
    if value.endswith("n"):
        return int(value[:-1]) // 1_000_000
    return int(float(value) * 1000)


def parse_mem_mi(value: str) -> int:
    value = value.strip().upper()
    match = re.match(r"(\d+(?:\.\d+)?)([A-Z]+)", value)
    if not match:
        return 0
    num = float(match.group(1))
    unit = match.group(2)
    if unit in {"KI", "K"}:
        return int(num / 1024)
    if unit in {"MI", "M"}:
        return int(num)
    if unit in {"GI", "G"}:
        return int(num * 1024)
    return int(num)


def get_node_metrics(node_name: str) -> dict[str, Any]:
    """获取单节点 CPU/内存使用率（远程 kubectl top node）。"""
    if not is_node_ready(node_name):
        return {"node_name": node_name, "ready": False, "error": "节点 NotReady"}

    code, out, err = run_kubectl(["top", "node", node_name, "--no-headers"])
    if code != 0:
        return {"node_name": node_name, "ready": True, "error": err or "指标采集失败"}

    parts = out.split()
    if len(parts) < 5:
        return {"node_name": node_name, "ready": True, "error": f"无法解析指标: {out}"}

    cpu_percent = parse_percent(parts[2])
    mem_percent = parse_percent(parts[4])
    high_load_type = "none"
    if cpu_percent > 70 and mem_percent > 70:
        high_load_type = "both"
    elif cpu_percent > 70:
        high_load_type = "cpu"
    elif mem_percent > 70:
        high_load_type = "mem"

    return {
        "node_name": node_name,
        "ready": True,
        "cpu_cores": parts[0],
        "cpu_percent": cpu_percent,
        "mem_used": parts[3],
        "mem_percent": mem_percent,
        "high_load": cpu_percent > 70 or mem_percent > 70,
        "high_load_type": high_load_type,
    }


def get_pods_on_node(node_name: str, top_n: int = 10) -> list[dict[str, Any]]:
    """按 CPU 使用量排序，返回节点上 TOP Pod。"""
    code, out, _ = run_kubectl([
        "top", "pods", "-A",
        "--field-selector", f"spec.nodeName={node_name}",
        "--no-headers",
    ])
    if code != 0:
        return []

    pods: list[dict[str, Any]] = []
    for line in out.splitlines():
        if not line.strip():
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        namespace, pod_name, cpu_raw, mem_raw = parts[0], parts[1], parts[2], parts[3]
        pods.append({
            "namespace": namespace,
            "pod_name": pod_name,
            "cpu": cpu_raw,
            "cpu_milli": parse_cpu_milli(cpu_raw),
            "mem": mem_raw,
            "mem_mi": parse_mem_mi(mem_raw),
            "is_core": is_core_component(namespace, pod_name),
        })

    pods.sort(key=lambda item: (item["cpu_milli"], item["mem_mi"]), reverse=True)
    return pods[:top_n] if top_n > 0 else pods


def is_core_component(namespace: str, pod_name: str) -> bool:
    if namespace in CORE_NAMESPACES:
        return True
    return any(keyword in pod_name for keyword in CORE_KEYWORDS)


def find_low_load_node(exclude: str | None = None, threshold: int = 50) -> str | None:
    """查找 CPU/内存均低于阈值的 Ready 节点。"""
    candidates: list[tuple[float, str]] = []
    for node in list_node_names():
        if exclude and node == exclude:
            continue
        metric = get_node_metrics(node)
        if not metric.get("ready") or metric.get("error"):
            continue
        if metric["cpu_percent"] < threshold and metric["mem_percent"] < threshold:
            score = metric["cpu_percent"] + metric["mem_percent"]
            candidates.append((score, node))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0])
    return candidates[0][1]
