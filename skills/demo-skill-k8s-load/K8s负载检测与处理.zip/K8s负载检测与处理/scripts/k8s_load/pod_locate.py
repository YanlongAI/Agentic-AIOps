#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""高负载 Pod 定位：在高负载节点上按资源用量排序 TOP Pod。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import check_cluster, emit, get_node_metrics, get_pods_on_node, list_node_names


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="K8s 高负载 Pod 定位")
    parser.add_argument("action", choices=["find"])
    parser.add_argument("--node-name", default="", help="目标节点，空则扫描全部高负载节点")
    parser.add_argument("--threshold", type=int, default=70, help="节点高负载阈值（%）")
    parser.add_argument("--top", type=int, default=5, help="每节点返回 TOP N Pod")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    ok, msg = check_cluster()
    if not ok:
        emit(1, msg)

    if args.node_name:
        target_nodes = [args.node_name]
    else:
        target_nodes = []
        for node in list_node_names():
            metric = get_node_metrics(node)
            if metric.get("error"):
                continue
            if metric.get("cpu_percent", 0) > args.threshold or metric.get("mem_percent", 0) > args.threshold:
                target_nodes.append(node)

    if not target_nodes:
        emit(0, "未发现高负载节点", {"high_load_pod_list": [], "high_load_pod_count": 0})

    pod_list: list[dict] = []
    for node in target_nodes:
        pods = get_pods_on_node(node, top_n=args.top)
        for pod in pods:
            pod["node_name"] = node
            pod_list.append(pod)

    pod_list.sort(key=lambda item: (item["cpu_milli"], item["mem_mi"]), reverse=True)
    emit(0, f"共定位 {len(pod_list)} 个高资源 Pod", {
        "high_load_pod_list": pod_list,
        "high_load_pod_count": len(pod_list),
        "target_nodes": target_nodes,
        "top_pods": pod_list[:3],
    })


if __name__ == "__main__":
    main()
