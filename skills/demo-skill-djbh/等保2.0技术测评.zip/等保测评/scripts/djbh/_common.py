# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""等保测评：SSH 连接与 PATROL_* 环境变量解析（平台 env_patrol 注入，同 Linux 服务器巡检）。"""

from __future__ import annotations

import io
import json
import os
import re
import shlex
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import paramiko

REPORT_DIR = Path(os.environ.get("PATROL_REPORT_DIR") or "./reports")


@dataclass
class SshTarget:
    name: str
    host: str
    port: int
    username: str
    password: str | None = None
    private_key: str | None = None


def emit(code: int, msg: str, data: dict[str, Any] | None = None) -> None:
    payload = {"code": code, "msg": msg, "data": data or {}}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    sys.exit(0 if code == 0 else 1)


def parse_patrol_server(raw: str) -> SshTarget:
    """解析平台注入的 PATROL_SERVER：name|user@host:port|tags。"""
    parts = [part.strip() for part in raw.split("|") if part.strip()]
    if len(parts) < 2:
        raise ValueError(f"PATROL_SERVER 格式无效: {raw}")

    name = parts[0]
    cred = parts[1]
    username = "root"
    host = "127.0.0.1"
    port = 22

    if "@" in cred:
        username, rest = cred.split("@", 1)
    else:
        rest = cred

    if ":" in rest:
        host, port_text = rest.rsplit(":", 1)
        port = int(port_text)
    else:
        host = rest

    password = os.environ.get("PATROL_SSH_PASSWORD") or os.environ.get("PATROL_PASSWORD")
    private_key = os.environ.get("PATROL_SSH_PRIVATE_KEY")
    per_host_password = parts[3] if len(parts) >= 4 and parts[3] else None

    return SshTarget(
        name=name,
        host=host.strip(),
        port=port,
        username=username.strip() or "root",
        password=per_host_password or password,
        private_key=private_key,
    )


def load_ssh_target() -> SshTarget:
    raw = os.environ.get("PATROL_SERVER", "").strip()
    if not raw:
        emit(1, "缺少 PATROL_SERVER，请绑定 server_instance 并由平台注入 SSH 凭证")
    try:
        target = parse_patrol_server(raw)
    except ValueError as exc:
        emit(1, str(exc))
    if not target.password and not target.private_key:
        emit(1, "缺少 SSH 凭证（PATROL_SSH_PASSWORD 或密钥），请检查 server_instance 配置")
    return target


def connect_ssh(target: SshTarget) -> paramiko.SSHClient:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    pkey = None
    if target.private_key:
        try:
            pkey = paramiko.RSAKey.from_private_key(io.StringIO(target.private_key))
        except paramiko.SSHException:
            pkey = paramiko.Ed25519Key.from_private_key(io.StringIO(target.private_key))
    client.connect(
        hostname=target.host,
        port=target.port,
        username=target.username,
        password=target.password if not pkey else None,
        pkey=pkey,
        timeout=int(os.environ.get("PATROL_SSH_TIMEOUT") or 30),
        banner_timeout=30,
    )
    transport = client.get_transport()
    if transport:
        transport.set_keepalive(30)
    return client


def run_remote(command: str, timeout: int = 120) -> tuple[int, str, str]:
    target = load_ssh_target()
    client = connect_ssh(target)
    try:
        _, stdout, stderr = client.exec_command(command, timeout=timeout)
        code = stdout.channel.recv_exit_status()
        out = stdout.read().decode("utf-8", errors="replace").strip()
        err = stderr.read().decode("utf-8", errors="replace").strip()
        return code, out, err
    finally:
        client.close()


def save_artifact(name: str, payload: dict[str, Any]) -> str:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    path = REPORT_DIR / f"{name}-{ts}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(path)


def parse_findings(text: str, pattern: str) -> list[str]:
    return re.findall(pattern, text, flags=re.I)


def level_from_count(crit: int, warn: int) -> str:
    if crit > 0:
        return "CRIT"
    if warn > 0:
        return "WARN"
    return "OK"
