#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""等保阶段1/2：端口与服务识别（区域边界、通信网络）。"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import emit, load_ssh_target, run_remote, save_artifact, level_from_count


DANGER_PORTS = "21,23,135,139,445,3389,6379,27017,2375,2376,6443,1521,1433,3306,11211,9200"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="等保端口与服务扫描")
    parser.add_argument("action", choices=["scan"])
    parser.add_argument("--target", default="", help="目标 IP 或 CIDR，默认使用绑定的 server_instance 主机")
    parser.add_argument("--ports", default=DANGER_PORTS, help="端口列表")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    target = load_ssh_target()
    scan_target = (args.target or target.host).strip()
    if not scan_target:
        emit(1, "缺少扫描目标：请绑定 server_instance 或传 --target")
    import shlex
    cmd = (
        f"nmap -sS -sV -T4 -p {shlex.quote(args.ports)} --open {shlex.quote(scan_target)} -oN - 2>/dev/null"
    )
    code, out, err = run_remote(cmd, timeout=600)
    open_ports: list[dict] = []
    for line in out.splitlines():
        if "/tcp" in line and "open" in line:
            parts = line.split()
            if len(parts) >= 3:
                port_proto = parts[0]
                port = port_proto.split("/")[0]
                service = parts[2] if len(parts) > 2 else "unknown"
                open_ports.append({"port": port, "proto": "tcp", "service": service, "line": line.strip()})

    crit = sum(1 for item in open_ports if item["port"] in {"23", "21", "6379", "27017", "2375"})
    warn = len(open_ports) - crit
    payload = {
        "phase": "port_service_scan",
        "target": scan_target,
        "target_host": {"host": target.host, "name": target.name},
        "open_ports": open_ports,
        "open_count": len(open_ports),
        "overall": level_from_count(crit, warn),
        "raw_excerpt": out[:12000],
        "error": err if code != 0 else "",
    }
    artifact = save_artifact("port_scan", payload)
    emit(0, f"开放端口 {len(open_ports)} 个，风险等级 {payload['overall']}", {**payload, "artifact": artifact})


if __name__ == "__main__":
    main()
