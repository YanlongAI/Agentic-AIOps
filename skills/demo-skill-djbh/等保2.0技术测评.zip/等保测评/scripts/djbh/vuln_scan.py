#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""等保阶段3：漏洞扫描（只读 nmap vuln 脚本，需书面授权）。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import emit, load_ssh_target, run_remote, save_artifact, parse_findings


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="等保漏洞扫描")
    parser.add_argument("action", choices=["scan"])
    parser.add_argument("--target", default="", help="目标 IP，默认使用绑定的 server_instance 主机")
    parser.add_argument("--confirm", default="false", help="必须 true 表示已获授权")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if str(args.confirm).lower() not in ("true", "1", "yes"):
        emit(1, "漏洞扫描需书面授权，请传 --confirm true")
    target = load_ssh_target()
    scan_target = (args.target or target.host).strip()
    if not scan_target:
        emit(1, "缺少漏洞扫描目标：请绑定 server_instance 或传 --target")
    import shlex
    cmd = (
        f"nmap --script vuln,smb-vuln-ms17-010,ssl-heartbleed --script-timeout 45s "
        f"-T4 {shlex.quote(scan_target)} -oN - 2>/dev/null"
    )
    code, out, err = run_remote(cmd, timeout=900)
    cves = parse_findings(out, r"CVE-\d{4}-\d+")
    vuln_lines = [line for line in out.splitlines() if "VULNERABLE" in line.upper() or "CVE-" in line.upper()]
    payload = {
        "phase": "vuln_scan",
        "target": scan_target,
        "target_host": {"host": target.host, "name": target.name},
        "cve_list": sorted(set(cves)),
        "vuln_lines": vuln_lines[:50],
        "vuln_count": len(vuln_lines),
        "raw_excerpt": out[:15000],
        "error": err if code != 0 else "",
    }
    artifact = save_artifact("vuln_scan", payload)
    emit(0, f"漏洞扫描完成，命中 {len(vuln_lines)} 条，CVE {len(set(cves))} 个", {**payload, "artifact": artifact})


if __name__ == "__main__":
    main()
