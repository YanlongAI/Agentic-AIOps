#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""等保：对当前绑定的目标 Linux 主机执行一站式技术测评（Agent 主入口）。"""

from __future__ import annotations

import argparse
import shlex
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import emit, level_from_count, load_ssh_target, run_remote, save_artifact
from linux_baseline import BASELINE_SCRIPT, evaluate, parse_sections
from port_scan import DANGER_PORTS

TLS_PROBE = (
    "openssl s_client -connect {host}:{port} -servername {host} </dev/null 2>/dev/null | "
    "openssl x509 -noout -subject -dates -issuer 2>/dev/null | head -20"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="等保目标主机一站式测评")
    parser.add_argument("action", choices=["assess"])
    parser.add_argument("--level", default="3", choices=["2", "3"], help="等保级别")
    parser.add_argument("--skip-tls", action="store_true", help="跳过 TLS 探测")
    return parser.parse_args()


def scan_ports(host: str) -> tuple[list[dict], str, str]:
    cmd = f"nmap -sS -sV -T4 -p {shlex.quote(DANGER_PORTS)} --open {shlex.quote(host)} -oN - 2>/dev/null"
    code, out, err = run_remote(cmd, timeout=600)
    open_ports: list[dict] = []
    for line in out.splitlines():
        if "/tcp" in line and "open" in line:
            parts = line.split()
            if len(parts) >= 3:
                port = parts[0].split("/")[0]
                service = parts[2] if len(parts) > 2 else "unknown"
                open_ports.append({"port": port, "service": service, "line": line.strip()})
    crit = sum(1 for item in open_ports if item["port"] in {"23", "21", "6379", "27017", "2375"})
    warn = len(open_ports) - crit
    return open_ports, level_from_count(crit, warn), err if code != 0 else ""


def check_tls(host: str, port: str = "443") -> dict:
    cmd = TLS_PROBE.format(host=shlex.quote(host), port=shlex.quote(port))
    code, out, err = run_remote(cmd, timeout=120)
    weak = []
    upper = out.upper()
    for algo in ("RC4", "MD5", "SSLV3", "TLSV1 ", "TLSV1.0"):
        if algo in upper:
            weak.append(algo.strip())
    return {
        "target": f"{host}:{port}",
        "weak_signals": weak,
        "overall": "WARN" if weak else ("OK" if out else "SKIP"),
        "detail": out[:4000],
        "error": err if code != 0 and not out else "",
    }


def main() -> None:
    args = parse_args()
    target = load_ssh_target()
    host = target.host

    baseline_cmd = f"bash -lc {shlex.quote(BASELINE_SCRIPT)}"
    code, out, err = run_remote(baseline_cmd, timeout=180)
    sections = parse_sections(out)
    baseline_findings, baseline_overall = evaluate(sections, args.level)

    open_ports, port_overall, port_err = scan_ports(host)
    tls_result = None
    if not args.skip_tls and any(item["port"] == "443" for item in open_ports):
        tls_result = check_tls(host, "443")

    findings = list(baseline_findings)
    if port_overall in {"CRIT", "WARN"}:
        findings.append(
            {
                "level": port_overall,
                "domain": "区域边界",
                "item": "高危端口暴露",
                "detail": open_ports[:8],
            }
        )
    if tls_result and tls_result["overall"] == "WARN":
        findings.append(
            {
                "level": "WARN",
                "domain": "通信网络",
                "item": "TLS 弱算法或配置",
                "detail": tls_result.get("weak_signals") or tls_result.get("detail", "")[:200],
            }
        )

    crit = sum(1 for item in findings if item["level"] == "CRIT")
    warn = sum(1 for item in findings if item["level"] == "WARN")
    overall = level_from_count(crit, warn)

    payload = {
        "phase": "target_assessment",
        "target": {"host": host, "name": target.name, "port": target.port},
        "assessment_level": args.level,
        "baseline": {
            "overall": baseline_overall,
            "findings": baseline_findings,
            "sections": {key: val[:10] for key, val in sections.items()},
            "error": err if code != 0 else "",
        },
        "port_scan": {
            "overall": port_overall,
            "open_ports": open_ports,
            "open_count": len(open_ports),
            "error": port_err,
        },
        "tls_check": tls_result,
        "findings": findings,
        "finding_count": len(findings),
        "overall": overall,
    }
    artifact = save_artifact("target_assessment", payload)
    emit(
        0 if overall != "CRIT" else 1,
        f"目标主机 {host} 测评完成：{len(findings)} 项风险，等级 {overall}",
        {**payload, "artifact": artifact},
    )


if __name__ == "__main__":
    main()
