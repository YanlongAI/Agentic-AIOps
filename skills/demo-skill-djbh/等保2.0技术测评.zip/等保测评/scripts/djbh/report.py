#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""等保阶段6：汇总 reports/*.json 生成测评技术附件报告。"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import REPORT_DIR, emit


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="等保报告汇总")
    parser.add_argument("action", choices=["generate"])
    parser.add_argument("--project-name", default="等保测评项目")
    parser.add_argument("--level", default="3")
    parser.add_argument("--report-path", default="./reports")
    return parser.parse_args()


def load_artifacts(report_path: Path) -> list[dict]:
    items = []
    for path in sorted(report_path.glob("*.json"), reverse=True):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            data["_file"] = path.name
            items.append(data)
        except json.JSONDecodeError:
            continue
    return items


def build_markdown(project: str, level: str, artifacts: list[dict]) -> str:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        f"# {project} — 等保{level}级技术测评附件",
        "",
        f"- 生成时间：{now}",
        f"- 依据：GB/T 22239-2019 / GB/T 28448-2019",
        f"- artifact 数量：{len(artifacts)}",
        "",
        "## 执行摘要",
        "",
    ]
    for art in artifacts:
        phase = art.get("phase", art.get("_file", "unknown"))
        overall = art.get("overall", "-")
        summary = art.get("live_count") or art.get("open_count") or art.get("finding_count") or art.get("vuln_count") or "-"
        lines.append(f"- **{phase}**：风险/结果 `{overall}`，指标 `{summary}`（{art.get('_file')}）")

    lines.extend(["", "## 风险明细", ""])
    for art in artifacts:
        findings = art.get("findings") or art.get("vuln_lines") or []
        if not findings:
            continue
        lines.append(f"### {art.get('phase', 'unknown')}")
        if isinstance(findings[0], dict):
            for item in findings:
                lines.append(f"- [{item.get('level','?')}] {item.get('domain','')}/{item.get('item','')}: {item.get('detail','')}")
        else:
            for line in findings[:20]:
                lines.append(f"- {line}")
        lines.append("")

    lines.extend([
        "## 后续步骤",
        "",
        "1. 完成安全管理域访谈（见 references/interview-guide.md）",
        "2. 填写测评记录表（templates/checklist.csv）",
        "3. 对 CRIT/WARN 项制定整改计划并安排复测",
        "",
    ])
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    report_path = Path(args.report_path)
    report_path.mkdir(parents=True, exist_ok=True)
    artifacts = load_artifacts(report_path)
    if not artifacts:
        emit(1, "reports/ 下无 JSON  artifact，请先执行 asset/port/baseline 等脚本")
    markdown = build_markdown(args.project_name, args.level, artifacts)
    filename = f"djbh-report-{datetime.now().strftime('%Y%m%d%H%M%S')}.md"
    full_path = report_path / filename
    full_path.write_text(markdown, encoding="utf-8")
    emit(0, f"报告已生成：{full_path}", {"report_path": str(full_path), "artifact_count": len(artifacts)})


if __name__ == "__main__":
    main()
