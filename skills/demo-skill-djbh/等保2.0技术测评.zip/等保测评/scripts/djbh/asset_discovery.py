#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""等保阶段1：资产发现（远程 nmap 存活探测）。"""

from __future__ import annotations

import argparse
import shlex
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import emit, load_ssh_target, run_remote, save_artifact


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="等保资产存活发现")
    parser.add_argument("action", choices=["scan"])
    parser.add_argument("--target-cidr", required=True, help="目标网段，如 192.168.1.0/24")
    parser.add_argument("--scan-speed", default="4", help="nmap -T 速率")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    target = load_ssh_target()
    cmd = (
        f"nmap -sn -PE -T{shlex.quote(args.scan_speed)} {shlex.quote(args.target_cidr)} "
        f"-oG - 2>/dev/null || ping -c 1 -W 1 {shlex.quote(args.target_cidr.split('/')[0])}"
    )
    code, out, err = run_remote(cmd, timeout=300)
    hosts = []
    for line in out.splitlines():
        if "Status: Up" in line and "Host:" in line:
            parts = line.split()
            for idx, part in enumerate(parts):
                if part == "Host:" and idx + 1 < len(parts):
                    hosts.append(parts[idx + 1])
    hosts = sorted(set(hosts))
    payload = {
        "phase": "asset_discovery",
        "jump_host": target.host,
        "target_cidr": args.target_cidr,
        "live_hosts": hosts,
        "live_count": len(hosts),
        "raw_excerpt": out[:8000],
        "error": err if code != 0 else "",
    }
    artifact = save_artifact("asset_discovery", payload)
    emit(0 if hosts else 1, f"发现 {len(hosts)} 台存活主机", {**payload, "artifact": artifact})


if __name__ == "__main__":
    main()
