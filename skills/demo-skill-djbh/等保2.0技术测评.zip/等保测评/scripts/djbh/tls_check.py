#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""等保：通信传输加密核查（TLS/SSL）。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import emit, load_ssh_target, run_remote, save_artifact


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="TLS 配置检查")
    parser.add_argument("action", choices=["check"])
    parser.add_argument("--target-host", default="", help="默认使用绑定的 server_instance 主机")
    parser.add_argument("--target-port", default="443")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    target = load_ssh_target()
    host_ip = (args.target_host or target.host).strip()
    if not host_ip:
        emit(1, "缺少 TLS 目标：请绑定 server_instance 或传 --target-host")
    import shlex
    host = shlex.quote(host_ip)
    port = shlex.quote(str(args.target_port))
    cmd = (
        f"(testssl.sh --quiet --color 0 {host}:{port} 2>/dev/null || "
        f"openssl s_client -connect {host}:{port} -servername {host} </dev/null 2>/dev/null | "
        f"openssl x509 -noout -subject -dates -issuer 2>/dev/null) | head -80"
    )
    code, out, err = run_remote(cmd, timeout=120)
    weak = []
    upper = out.upper()
    for algo in ("RC4", "MD5", "SSLV3", "TLSV1 ", "TLSV1.0"):
        if algo in upper:
            weak.append(algo.strip())
    payload = {
        "phase": "tls_check",
        "target": f"{host_ip}:{args.target_port}",
        "target_host": {"host": target.host, "name": target.name},
        "weak_signals": weak,
        "overall": "WARN" if weak else "OK",
        "detail": out[:6000],
        "error": err if code != 0 else "",
    }
    artifact = save_artifact("tls_check", payload)
    emit(0, f"TLS 检查完成，状态 {payload['overall']}", {**payload, "artifact": artifact})


if __name__ == "__main__":
    main()
