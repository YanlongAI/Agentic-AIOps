#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""等保阶段2：安全计算环境基线（身份鉴别/访问控制/审计/入侵防范）。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import emit, load_ssh_target, run_remote, save_artifact, level_from_count

BASELINE_SCRIPT = r"""set -e
echo '===PASSWD_POLICY==='
grep -E '^PASS_MAX_DAYS|^PASS_MIN_DAYS|^PASS_MIN_LEN|^PASS_WARN_AGE' /etc/login.defs 2>/dev/null || true
test -f /etc/security/pwquality.conf && grep -v '^#' /etc/security/pwquality.conf | grep -v '^$' || true
echo '===EMPTY_ACCOUNTS==='
awk -F: '($2=="" || $2=="!" || $2=="*"){print $1}' /etc/shadow 2>/dev/null || true
echo '===ROOT_REMOTE==='
grep -E '^PermitRootLogin|^PasswordAuthentication' /etc/ssh/sshd_config 2>/dev/null || true
echo '===PRIV_USERS==='
awk -F: '($3==0){print $1}' /etc/passwd
echo '===WORLD_WRITABLE==='
find /etc -type f -perm -o+w 2>/dev/null | head -20
echo '===SUID_SGID==='
find / -xdev \( -perm -4000 -o -perm -2000 \) -type f 2>/dev/null | head -30
echo '===AUDITD==='
systemctl is-active auditd 2>/dev/null || echo inactive
auditctl -l 2>/dev/null | head -10 || true
echo '===FAILED_SERVICES==='
systemctl list-units --type=service --state=failed --no-legend 2>/dev/null | awk '{print $1}' | head -10
echo '===LISTEN_PORTS==='
ss -tlnp 2>/dev/null | head -30 || netstat -tlnp 2>/dev/null | head -30
echo '===HIDS==='
ps aux 2>/dev/null | grep -iE 'aide|tripwire|wazuh|ossec' | grep -v grep || true
getenforce 2>/dev/null || true
"""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="等保 Linux 基线核查")
    parser.add_argument("action", choices=["check"])
    parser.add_argument("--level", default="3", choices=["2", "3"], help="等保级别")
    return parser.parse_args()


def parse_sections(raw: str) -> dict[str, list[str]]:
    sections: dict[str, list[str]] = {}
    current = "_meta"
    for line in raw.splitlines():
        if line.startswith("===") and line.endswith("==="):
            current = line.strip("=")
            sections[current] = []
            continue
        sections.setdefault(current, []).append(line)
    return sections


def evaluate(sections: dict[str, list[str]], level: str) -> tuple[list[dict], str]:
    findings: list[dict] = []
    empty = [line for line in sections.get("EMPTY_ACCOUNTS", []) if line.strip()]
    if empty:
        findings.append({"level": "CRIT", "domain": "身份鉴别", "item": "空口令/未锁定账户", "detail": empty[:5]})
    root_login = " ".join(sections.get("ROOT_REMOTE", []))
    if "PermitRootLogin yes" in root_login.replace(" ", ""):
        findings.append({"level": "WARN", "domain": "身份鉴别", "item": "允许 root 远程登录", "detail": root_login})
    world_w = [line for line in sections.get("WORLD_WRITABLE", []) if line.strip()]
    if world_w:
        findings.append({"level": "WARN", "domain": "访问控制", "item": "/etc 下全局可写文件", "detail": world_w[:5]})
    audit = " ".join(sections.get("AUDITD", []))
    if "inactive" in audit:
        findings.append({"level": "WARN", "domain": "安全审计", "item": "auditd 未运行", "detail": audit})
    failed = [line for line in sections.get("FAILED_SERVICES", []) if line.strip()]
    if failed:
        findings.append({"level": "WARN", "domain": "入侵防范", "item": "failed systemd 单元", "detail": failed})
    hids = " ".join(sections.get("HIDS", []))
    selinux = hids.split()[-1] if hids else ""
    if level == "3" and not hids.strip() and selinux not in {"Enforcing", "Permissive"}:
        findings.append({"level": "WARN", "domain": "入侵防范", "item": "未检测到 HIDS/SELinux", "detail": hids or "none"})
    crit = sum(1 for item in findings if item["level"] == "CRIT")
    warn = sum(1 for item in findings if item["level"] == "WARN")
    return findings, level_from_count(crit, warn)


def main() -> None:
    args = parse_args()
    target = load_ssh_target()
    import shlex
    cmd = f"bash -lc {shlex.quote(BASELINE_SCRIPT)}"
    code, out, err = run_remote(cmd, timeout=180)
    sections = parse_sections(out)
    findings, overall = evaluate(sections, args.level)
    payload = {
        "phase": "linux_baseline",
        "target": {"host": target.host, "name": target.name},
        "assessment_level": args.level,
        "sections": {key: val[:20] for key, val in sections.items()},
        "findings": findings,
        "finding_count": len(findings),
        "overall": overall,
        "error": err if code != 0 else "",
    }
    artifact = save_artifact("linux_baseline", payload)
    emit(0 if overall != "CRIT" else 1, f"基线核查完成，{len(findings)} 项风险，等级 {overall}", {**payload, "artifact": artifact})


if __name__ == "__main__":
    main()
