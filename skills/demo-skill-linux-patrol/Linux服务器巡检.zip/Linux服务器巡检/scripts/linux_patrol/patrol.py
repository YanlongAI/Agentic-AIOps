#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""Linux 服务器只读健康巡检（SSH 远程执行）。"""

from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import (
    connect_ssh,
    emit,
    evaluate_metrics,
    load_ssh_target,
    load_thresholds,
    parse_probe_output,
    run_remote_probe,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Linux 服务器只读巡检")
    parser.add_argument("action", choices=["check", "quick", "report"])
    parser.add_argument("--report-path", default="./reports", help="报告输出目录")
    parser.add_argument("--disk-warn", default=None)
    parser.add_argument("--disk-crit", default=None)
    parser.add_argument("--mem-warn", default=None)
    parser.add_argument("--mem-crit", default=None)
    parser.add_argument("--load-warn", default=None)
    parser.add_argument("--load-crit", default=None)
    parser.add_argument("--cpu-warn", default=None)
    return parser.parse_args()


def apply_threshold_overrides(args: argparse.Namespace) -> None:
    mapping = {
        "disk-warn": "PATROL_DISK_WARN",
        "disk-crit": "PATROL_DISK_CRIT",
        "mem-warn": "PATROL_MEM_WARN",
        "mem-crit": "PATROL_MEM_CRIT",
        "load-warn": "PATROL_LOAD_WARN",
        "load-crit": "PATROL_LOAD_CRIT",
        "cpu-warn": "PATROL_CPU_WARN",
    }
    for arg_key, env_key in mapping.items():
        attr = arg_key.replace("-", "_")
        value = getattr(args, attr, None)
        if value is not None:
            os.environ[env_key] = str(value)


def collect_metrics(quick: bool = False) -> dict:
    target = load_ssh_target()
    thresholds = load_thresholds()
    client = connect_ssh(target)
    try:
        raw = run_remote_probe(client)
    finally:
        client.close()

    metrics = parse_probe_output(raw)
    evaluation = evaluate_metrics(metrics, thresholds, quick=quick)
    return {
        "target": {
            "name": target.name,
            "host": target.host,
            "port": target.port,
            "username": target.username,
        },
        "metrics": metrics,
        "evaluation": evaluation,
        "thresholds": {
            "disk_warn": thresholds.disk_warn,
            "disk_crit": thresholds.disk_crit,
            "mem_warn": thresholds.mem_warn,
            "mem_crit": thresholds.mem_crit,
            "load_warn": thresholds.load_warn,
            "load_crit": thresholds.load_crit,
            "cpu_warn": thresholds.cpu_warn,
        },
    }


def build_markdown(payload: dict) -> str:
    target = payload["target"]
    metrics = payload["metrics"]
    evaluation = payload["evaluation"]
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "# Linux 服务器巡检报告",
        "",
        f"- 生成时间：{now}",
        f"- 目标：{target['name']} ({target['username']}@{target['host']}:{target['port']})",
        f"- 总体状态：**{evaluation['overall']}**",
        "",
        "## 基础信息",
        "",
        f"- 主机名：{metrics['host']}",
        f"- 运行时长：{metrics['uptime']}",
        f"- 负载(1m)：{metrics['load_1']} / CPU核数：{metrics['cpu_cores']}",
        f"- CPU 使用率：{metrics['cpu_usage_pct']}%",
        f"- 内存：{metrics['memory']['used_mb']}MB / {metrics['memory']['total_mb']}MB "
        f"({metrics['memory']['used_pct']}%)",
        "",
        "## 磁盘",
        "",
    ]
    if metrics["disks"]:
        for disk in metrics["disks"]:
            lines.append(
                f"- `{disk['mount']}`：{disk['used_pct']}% 已用，可用 {disk['avail']}，"
                f"总量 {disk['total']}"
            )
    else:
        lines.append("- 无数据")

    if metrics["systemd"]["summary"]:
        summary = metrics["systemd"]["summary"]
        lines.extend([
            "",
            "## Systemd",
            "",
            f"- running: {summary.get('running', 0)}，failed: {summary.get('failed', 0)}",
        ])
        if metrics["systemd"]["failed_units"]:
            lines.append("- failed 单元：" + ", ".join(metrics["systemd"]["failed_units"]))

    if metrics["processes"]["top_by_cpu"]:
        lines.extend(["", "## TOP 进程 (CPU)", ""])
        for proc in metrics["processes"]["top_by_cpu"]:
            lines.append(f"- {proc['command']}：CPU {proc['cpu']}%，MEM {proc['mem']}%")

    if metrics.get("docker"):
        lines.extend([
            "",
            "## Docker",
            "",
            f"- running: {metrics['docker'].get('running', 0)}，"
            f"total: {metrics['docker'].get('total', 0)}",
        ])

    lines.extend(["", "## 风险项", ""])
    if evaluation["findings"]:
        for item in evaluation["findings"]:
            lines.append(f"- [{item['level']}] {item['message']}")
    else:
        lines.append("- 无 WARN/CRIT 项")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    apply_threshold_overrides(args)
    quick = args.action == "quick"

    try:
        payload = collect_metrics(quick=quick)
    except Exception as exc:
        emit(1, f"巡检失败: {exc}")

    evaluation = payload["evaluation"]
    msg = f"巡检完成，总体状态 {evaluation['overall']}，发现 {evaluation['finding_count']} 项风险"

    if args.action == "report":
        os.makedirs(args.report_path, exist_ok=True)
        filename = f"linux-patrol-{datetime.now().strftime('%Y%m%d%H%M%S')}.md"
        full_path = os.path.join(args.report_path, filename)
        markdown = build_markdown(payload)
        with open(full_path, "w", encoding="utf-8") as handle:
            handle.write(markdown)
        payload["report"] = {
            "path": full_path,
            "size_bytes": os.path.getsize(full_path),
        }
        msg = f"报告已生成：{full_path}"

    code = 0 if evaluation["overall"] != "CRIT" else 1
    emit(code, msg, payload)


if __name__ == "__main__":
    main()
