# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""Linux 服务器只读巡检：SSH 连接与 PATROL_* 环境变量解析（平台 env_patrol 注入）。"""

from __future__ import annotations

import io
import json
import os
import re
import sys
from dataclasses import dataclass
from typing import Any

import paramiko

REMOTE_PROBE = r"""set -e
echo "===HOST==="
hostname -s 2>/dev/null || hostname
echo "===UPTIME==="
uptime 2>/dev/null || true
echo "===LOAD==="
if [ -r /proc/loadavg ]; then awk '{print $1" "$2" "$3}' /proc/loadavg; else echo "0 0 0"; fi
echo "===CPU_CORES==="
nproc 2>/dev/null || echo 1
echo "===CPU_USAGE==="
if [ -r /proc/stat ]; then
  read -r _ u1 n1 s1 i1 iw1 irq1 sirq1 _ < /proc/stat
  t1=$((u1+n1+s1+i1+iw1+irq1+sirq1)); id1=$i1
  sleep 1
  read -r _ u2 n2 s2 i2 iw2 irq2 sirq2 _ < /proc/stat
  t2=$((u2+n2+s2+i2+iw2+irq2+sirq2)); id2=$i2
  dt=$((t2-t1)); di=$((id2-id1))
  if [ "$dt" -gt 0 ]; then echo $(( (100 * (dt - di)) / dt )); else echo 0; fi
else echo 0; fi
echo "===MEM==="
if command -v free >/dev/null 2>&1; then
  free -m | awk '/^Mem:/ {printf "total=%s used=%s avail=%s pct=%.0f\n", $2, $3, $7, ($3/$2)*100}'
else echo "total=0 used=0 avail=0 pct=0"; fi
echo "===SWAP==="
free -m 2>/dev/null | awk '/^Swap:/ {printf "total=%s used=%s pct=%.0f\n", $2, $3, ($2>0?$3/$2*100:0)}'
swapon --show 2>/dev/null | head -5
echo "===DISK==="
df -P 2>/dev/null | awk 'NR>1 && $6 ~ /^\// && $1 !~ /tmpfs|devtmpfs|overlay/ {gsub(/%/,"",$5); print $6":"$5":"$4":"$2}'
echo "===DISK_DF==="
df -hPT / /var /data /home /opt 2>/dev/null
echo "===DISK_INODE==="
df -iP / /var 2>/dev/null
echo "===DISK_LSBLK==="
lsblk -dn -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT,FSUSE% 2>/dev/null | head -30
echo "===NET==="
ip -br addr 2>/dev/null || ip addr 2>/dev/null | head -20
echo "===NET_LISTEN==="
ss -tlnp 2>/dev/null | head -15
echo "===NET_STATS==="
ss -s 2>/dev/null | head -12
echo "===SYSTEMD==="
if command -v systemctl >/dev/null 2>&1; then
  running=$(systemctl list-units --type=service --state=running --no-legend 2>/dev/null | wc -l | tr -d ' ')
  failed=$(systemctl list-units --type=service --state=failed --no-legend 2>/dev/null | wc -l | tr -d ' ')
  echo "summary|running=${running}|failed=${failed}"
  systemctl list-units --type=service --state=failed --no-legend 2>/dev/null | awk '{print $1"|failed"}' | head -10
else echo "systemd|unavailable"; fi
echo "===PROCESSES==="
if command -v ps >/dev/null 2>&1; then
  total=$(ps -e --no-header 2>/dev/null | wc -l | tr -d ' ')
  zombie=$(ps aux 2>/dev/null | awk '$8 ~ /Z/ {c++} END {print c+0}')
  echo "summary|total=${total}|zombie=${zombie}"
  ps -eo comm=,pcpu=,pmem= --sort=-pcpu 2>/dev/null | head -5 | awk '{print $1"|cpu="$2"|mem="$3}'
else echo "processes|unavailable"; fi
echo "===DOCKER==="
if command -v docker >/dev/null 2>&1; then
  running=$(docker ps -q 2>/dev/null | wc -l | tr -d ' ')
  total=$(docker ps -aq 2>/dev/null | wc -l | tr -d ' ')
  echo "summary|running=${running}|total=${total}"
else echo "docker|unavailable"; fi
"""


@dataclass
class SshTarget:
    name: str
    host: str
    port: int
    username: str
    password: str | None = None
    private_key: str | None = None


@dataclass
class Thresholds:
    disk_warn: int = 80
    disk_crit: int = 90
    mem_warn: int = 85
    mem_crit: int = 95
    load_warn: float = 5.0
    load_crit: float = 10.0
    cpu_warn: int = 80


def emit(code: int, msg: str, data: dict[str, Any] | None = None) -> None:
    payload = {"code": code, "msg": msg, "data": data or {}}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    sys.exit(0 if code == 0 else 1)


def load_thresholds() -> Thresholds:
    return Thresholds(
        disk_warn=int(os.environ.get("PATROL_DISK_WARN") or 80),
        disk_crit=int(os.environ.get("PATROL_DISK_CRIT") or 90),
        mem_warn=int(os.environ.get("PATROL_MEM_WARN") or 85),
        mem_crit=int(os.environ.get("PATROL_MEM_CRIT") or 95),
        load_warn=float(os.environ.get("PATROL_LOAD_WARN") or 5),
        load_crit=float(os.environ.get("PATROL_LOAD_CRIT") or 10),
        cpu_warn=int(os.environ.get("PATROL_CPU_WARN") or 80),
    )


def parse_patrol_server(raw: str) -> SshTarget:
    """解析平台注入的 PATROL_SERVER：name|user@host:port|tags。"""
    parts = [part.strip() for part in raw.split("|") if part.strip()]
    if len(parts) < 2:
        raise ValueError(f"PATROL_SERVER 格式无效: {raw}")

    name = parts[0]
    cred = parts[1]
    username = "root"
    host = "127.0.0.1"
    port = 22

    if "@" in cred:
        username, rest = cred.split("@", 1)
    else:
        rest = cred

    if ":" in rest:
        host, port_text = rest.rsplit(":", 1)
        port = int(port_text)
    else:
        host = rest

    password = os.environ.get("PATROL_SSH_PASSWORD") or os.environ.get("PATROL_PASSWORD")
    private_key = os.environ.get("PATROL_SSH_PRIVATE_KEY")
    per_host_password = parts[3] if len(parts) >= 4 and parts[3] else None

    return SshTarget(
        name=name,
        host=host.strip(),
        port=port,
        username=username.strip() or "root",
        password=per_host_password or password,
        private_key=private_key,
    )


def load_ssh_target() -> SshTarget:
    raw = os.environ.get("PATROL_SERVER", "").strip()
    if not raw:
        emit(1, "缺少 PATROL_SERVER，请绑定 server_instance 并由平台注入 SSH 凭证")
    try:
        target = parse_patrol_server(raw)
    except ValueError as exc:
        emit(1, str(exc))
    if not target.password and not target.private_key:
        emit(1, "缺少 SSH 凭证（PATROL_SSH_PASSWORD 或密钥），请检查 server_instance 配置")
    return target


def connect_ssh(target: SshTarget) -> paramiko.SSHClient:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    pkey = None
    if target.private_key:
        try:
            pkey = paramiko.RSAKey.from_private_key(io.StringIO(target.private_key))
        except paramiko.SSHException:
            pkey = paramiko.Ed25519Key.from_private_key(io.StringIO(target.private_key))
    client.connect(
        hostname=target.host,
        port=target.port,
        username=target.username,
        password=target.password if not pkey else None,
        pkey=pkey,
        timeout=int(os.environ.get("PATROL_SSH_TIMEOUT") or 30),
        banner_timeout=30,
    )
    transport = client.get_transport()
    if transport:
        transport.set_keepalive(30)
    return client


def run_remote_probe(client: paramiko.SSHClient) -> str:
    _, stdout, stderr = client.exec_command(REMOTE_PROBE, timeout=90)
    exit_code = stdout.channel.recv_exit_status()
    out = stdout.read().decode("utf-8", errors="replace")
    err = stderr.read().decode("utf-8", errors="replace").strip()
    if exit_code != 0:
        raise RuntimeError(err or f"远程探测失败，exit={exit_code}")
    return out


def parse_probe_output(raw: str) -> dict[str, Any]:
    sections: dict[str, list[str]] = {}
    current = "_meta"
    sections[current] = []
    for line in raw.splitlines():
        if line.startswith("===") and line.endswith("==="):
            current = line.strip("=")
            sections[current] = []
            continue
        sections.setdefault(current, []).append(line)

    host = (sections.get("HOST") or ["unknown"])[0].strip()
    uptime = " ".join(sections.get("UPTIME") or []).strip()
    load_parts = (sections.get("LOAD") or ["0", "0", "0"])[0].split()
    load_1 = float(load_parts[0]) if load_parts else 0.0
    cpu_cores = int((sections.get("CPU_CORES") or ["1"])[0].strip() or 1)
    cpu_usage = int(float((sections.get("CPU_USAGE") or ["0"])[0].strip() or 0))

    mem_line = (sections.get("MEM") or ["total=0 used=0 avail=0 pct=0"])[0]
    mem_match = re.search(
        r"total=(\d+)\s+used=(\d+)\s+avail=(\d+)\s+pct=(\d+)",
        mem_line,
    )
    mem = {
        "total_mb": int(mem_match.group(1)) if mem_match else 0,
        "used_mb": int(mem_match.group(2)) if mem_match else 0,
        "avail_mb": int(mem_match.group(3)) if mem_match else 0,
        "used_pct": int(mem_match.group(4)) if mem_match else 0,
    }

    disks = []
    for line in sections.get("DISK") or []:
        if not line.strip() or ":" not in line:
            continue
        mount, pct, avail, total = line.split(":", 3)
        disks.append({
            "mount": mount,
            "used_pct": int(float(pct)),
            "avail": avail,
            "total": total,
        })

    systemd_failed = []
    systemd_summary = {}
    for line in sections.get("SYSTEMD") or []:
        if line.startswith("summary|"):
            for item in line.split("|")[1:]:
                if "=" in item:
                    key, val = item.split("=", 1)
                    systemd_summary[key] = int(val)
        elif "|failed" in line:
            systemd_failed.append(line.split("|")[0])

    top_processes = []
    proc_summary = {}
    for line in sections.get("PROCESSES") or []:
        if line.startswith("summary|"):
            for item in line.split("|")[1:]:
                if "=" in item:
                    key, val = item.split("=", 1)
                    proc_summary[key] = int(val)
        elif "|cpu=" in line:
            comm, rest = line.split("|", 1)
            cpu_match = re.search(r"cpu=([\d.]+)", rest)
            mem_match = re.search(r"mem=([\d.]+)", rest)
            top_processes.append({
                "command": comm,
                "cpu": float(cpu_match.group(1)) if cpu_match else 0,
                "mem": float(mem_match.group(1)) if mem_match else 0,
            })

    docker_summary = {}
    for line in sections.get("DOCKER") or []:
        if line.startswith("summary|"):
            for item in line.split("|")[1:]:
                if "=" in item:
                    key, val = item.split("=", 1)
                    docker_summary[key] = int(val)

    return {
        "host": host,
        "uptime": uptime,
        "load_1": load_1,
        "cpu_cores": cpu_cores,
        "cpu_usage_pct": cpu_usage,
        "memory": mem,
        "disks": disks,
        "systemd": {"summary": systemd_summary, "failed_units": systemd_failed},
        "processes": {"summary": proc_summary, "top_by_cpu": top_processes},
        "docker": docker_summary,
    }


def severity_max(items: list[str]) -> str:
    if "CRIT" in items:
        return "CRIT"
    if "WARN" in items:
        return "WARN"
    return "OK"


def evaluate_metrics(metrics: dict[str, Any], thresholds: Thresholds, quick: bool = False) -> dict[str, Any]:
    findings: list[dict[str, str]] = []

    if metrics["cpu_usage_pct"] >= thresholds.cpu_warn:
        findings.append({
            "level": "WARN",
            "item": "cpu",
            "message": f"CPU 使用率 {metrics['cpu_usage_pct']}% >= {thresholds.cpu_warn}%",
        })

    mem_pct = metrics["memory"]["used_pct"]
    if mem_pct >= thresholds.mem_crit:
        findings.append({
            "level": "CRIT",
            "item": "memory",
            "message": f"内存使用率 {mem_pct}% >= {thresholds.mem_crit}%",
        })
    elif mem_pct >= thresholds.mem_warn:
        findings.append({
            "level": "WARN",
            "item": "memory",
            "message": f"内存使用率 {mem_pct}% >= {thresholds.mem_warn}%",
        })

    if metrics["load_1"] >= thresholds.load_crit:
        findings.append({
            "level": "CRIT",
            "item": "load",
            "message": f"1分钟负载 {metrics['load_1']} >= {thresholds.load_crit}",
        })
    elif metrics["load_1"] >= thresholds.load_warn:
        findings.append({
            "level": "WARN",
            "item": "load",
            "message": f"1分钟负载 {metrics['load_1']} >= {thresholds.load_warn}",
        })

    for disk in metrics["disks"]:
        pct = disk["used_pct"]
        if pct >= thresholds.disk_crit:
            findings.append({
                "level": "CRIT",
                "item": "disk",
                "message": f"磁盘 {disk['mount']} 使用率 {pct}% >= {thresholds.disk_crit}%",
            })
        elif pct >= thresholds.disk_warn:
            findings.append({
                "level": "WARN",
                "item": "disk",
                "message": f"磁盘 {disk['mount']} 使用率 {pct}% >= {thresholds.disk_warn}%",
            })

    if not quick:
        failed_count = metrics["systemd"]["summary"].get("failed", 0)
        if failed_count > 0:
            findings.append({
                "level": "WARN",
                "item": "systemd",
                "message": f"存在 {failed_count} 个 failed systemd 单元",
            })
        zombie = metrics["processes"]["summary"].get("zombie", 0)
        if zombie > 0:
            findings.append({
                "level": "WARN",
                "item": "process",
                "message": f"存在 {zombie} 个僵尸进程",
            })

    overall = severity_max([item["level"] for item in findings] or ["OK"])
    return {"overall": overall, "findings": findings, "finding_count": len(findings)}
