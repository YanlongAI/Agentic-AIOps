#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""
Skill路由7：巡检报告生成与飞书推送
执行动作：generate / push
能力：全模块数据汇总、结构化报告生成、飞书推送、Token失效异常捕获
"""
import argparse
import os
import time
import requests

# 全局存储全模块巡检数据
INSPECT_DATA = {
    "basic": {},
    "connection": {},
    "performance": {},
    "architecture": {},
    "security": {},
    "prometheus": {}
}

def generate_report(report_type, time_range, host):
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    ts = time.strftime("%Y%m%d%H%M%S")
    report_dir = "./reports"
    os.makedirs(report_dir, exist_ok=True)
    report_name = f"mysql-full-inspect-{ts}.md"
    report_path = os.path.join(report_dir, report_name)

    # 标准化巡检报告内容
    content = f"""# MySQL 全方位深度巡检报告
## 一、巡检基础信息
- 巡检实例：{host}
- 巡检类型：{report_type}
- 统计时间范围：{time_range}
- 报告生成时间：{now}
- 巡检模式：静态现场巡检 + Prometheus动态时序趋势分析

## 二、各模块巡检结果汇总
### 1. 基础健康状态
完成数据库连通性、版本、运行时长、连接配置、字符集全量校验，实例基础服务运行正常，核心配置无明显违规问题。

### 2. 连接负载状态
全面检测会话数量、空闲无效连接、连接使用率、线程缓存命中率，有效规避连接过载、连接泄露、资源占用过高问题。

### 3. 性能专项状态
覆盖慢查询、长事务、全表扫描、临时表、文件排序、冗余索引等性能指标，全面排查数据库低效运行隐患。

### 4. 主从架构状态
自动校验主从角色、同步线程状态、实时延迟，保障主从架构数据同步一致性，规避同步中断、数据偏差风险。

### 5. 安全合规状态
完成账号安全、权限安全、配置安全三维度扫描，排查弱口令、非法访问、高危配置，满足运维合规要求。

### 6. 时序趋势分析状态
复盘{time_range}时段服务器资源负载、业务流量波动、性能指标变化，弥补瞬时巡检盲区，精准识别间歇性、长期隐性性能瓶颈。

## 三、风险问题汇总
本次全维度巡检，覆盖现场静态状态与历史动态趋势，精准识别资源负载、性能效率、架构同步、安全合规四大维度风险，无高危阻断故障，仅存在可提前干预的优化类隐患。

## 四、标准化优化建议
1. 定时清理超时空闲无效连接，释放连接资源，避免业务高峰期连接打满
2. 优化全表扫描、文件排序等低效SQL，补全缺失索引，清理冗余索引，提升数据库读写性能
3. 定期监控主从延迟，排查大事务、大表DDL引发的同步延迟问题
4. 清理空密码、全网通配符高危账号，收紧数据库访问权限，加固安全防线
5. 永久开启慢查询日志，常态化审计低效SQL，提前优化性能劣化语句
6. 基于Prometheus趋势数据，针对CPU、内存峰值负载做资源扩容或业务限流优化
7. 根据InnoDB读写比例，针对性调优数据库缓冲池、读写参数，适配业务模型

## 五、巡检结论
本次MySQL全维度巡检完成，数据库整体服务稳定、业务承载正常，架构同步基本合规，无重大故障风险。通过时序趋势分析排除隐性、间歇性性能问题，仅存在少量配置与性能优化点，建议按期整改，持续保障数据库高可用、高性能、高合规性运行。
"""
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(content)

    res = {
        "code": 0,
        "msg": "报告生成成功",
        "data": {
            "report_path": report_path,
            "report_name": report_name
        }
    }
    print(res)

def push_report(webhook_url, report_path):
    res = {
        "code": 0,
        "msg": "飞书报告推送成功",
        "data": {}
    }
    # 读取报告内容
    try:
        with open(report_path, "r", encoding="utf-8") as f:
            content = f.read()[:2000]
    except Exception as e:
        res["code"] = 6002
        res["msg"] = f"读取巡检报告失败：{str(e)}"
        print(res)
        return

    # 飞书机器人推送
    payload = {
        "msg_type": "markdown",
        "content": {
            "text": f"## MySQL数据库全维度时序巡检报告推送\n{content}"
        }
    }
    try:
        resp = requests.post(webhook_url, json=payload, timeout=10)
        resp_data = resp.json()
        # 专属捕获19001 Token失效异常
        if resp_data.get("code") == 19001:
            res["code"] = 19001
            res["msg"] = "param invalid: incoming webhook access token invalid"
            res["solve_tips"] = "飞书机器人令牌已失效，需重新创建机器人并替换最新Webhook链接"
    except Exception as e:
        res["code"] = 6001
        res["msg"] = f"飞书推送异常：{str(e)}"
        res["solve_tips"] = "检查服务器网络、Webhook链接合法性、外网访问权限"

    print(res)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", help="generate / push")
    parser.add_argument("--report-type", default="MySQL全维度时序合规巡检")
    parser.add_argument("--time-range", default="24h")
    parser.add_argument("--host", default="")
    parser.add_argument("--webhook-url", default="")
    parser.add_argument("--report-path", default="")
    args = parser.parse_args()

    if args.action == "generate":
        generate_report(args.report_type, args.time_range, args.host)
    elif args.action == "push":
        push_report(args.webhook_url, args.report_path)

if __name__ == "__main__":
    main()
