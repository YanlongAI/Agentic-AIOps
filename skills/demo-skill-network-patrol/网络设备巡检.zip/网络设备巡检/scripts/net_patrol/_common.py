# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""网络设备只读巡检：SSH CLI 会话、厂商驱动注册与评估。"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from dataclasses import dataclass
from typing import Any, Protocol

import paramiko


class VendorDriver(Protocol):
    name: str
    aliases: tuple[str, ...]

    def prepare_session(self, shell: paramiko.Channel) -> None: ...

    def probe_version(self, shell: paramiko.Channel) -> str: ...

    def collect_quick(self, shell: paramiko.Channel) -> dict[str, Any]: ...

    def collect_full(self, shell: paramiko.Channel, quick: dict[str, Any]) -> dict[str, Any]: ...


@dataclass
class SshTarget:
    name: str
    host: str
    port: int
    username: str
    password: str | None = None
    private_key: str | None = None


@dataclass
class Thresholds:
    cpu_warn: int = 80
    cpu_crit: int = 90
    mem_warn: int = 85
    mem_crit: int = 95
    iface_down_warn: int = 3


def emit(code: int, msg: str, data: dict[str, Any] | None = None) -> None:
    payload = {"code": code, "msg": msg, "data": data or {}}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    sys.exit(0 if code == 0 else 1)


def load_thresholds() -> Thresholds:
    return Thresholds(
        cpu_warn=int(os.environ.get("PATROL_CPU_WARN") or 80),
        cpu_crit=int(os.environ.get("PATROL_CPU_CRIT") or 90),
        mem_warn=int(os.environ.get("PATROL_MEM_WARN") or 85),
        mem_crit=int(os.environ.get("PATROL_MEM_CRIT") or 95),
        iface_down_warn=int(os.environ.get("PATROL_IFACE_DOWN_WARN") or 3),
    )


def parse_patrol_server(raw: str) -> SshTarget:
    parts = [part.strip() for part in raw.split("|") if part.strip()]
    if len(parts) < 2:
        raise ValueError(f"PATROL_SERVER 格式无效: {raw}")

    name = parts[0]
    cred = parts[1]
    username = "admin"
    host = "127.0.0.1"
    port = 22

    if "@" in cred:
        username, rest = cred.split("@", 1)
    else:
        rest = cred

    if ":" in rest:
        host, port_text = rest.rsplit(":", 1)
        port = int(port_text)
    else:
        host = rest

    password = os.environ.get("PATROL_SSH_PASSWORD") or os.environ.get("PATROL_PASSWORD")
    private_key = os.environ.get("PATROL_SSH_PRIVATE_KEY")

    return SshTarget(
        name=name,
        host=host.strip(),
        port=port,
        username=username.strip() or "admin",
        password=password,
        private_key=private_key,
    )


def load_ssh_target() -> SshTarget:
    raw = os.environ.get("PATROL_SERVER", "").strip()
    if not raw:
        emit(1, "缺少 PATROL_SERVER，请绑定 server_instance 并由平台注入 SSH 凭证")
    try:
        target = parse_patrol_server(raw)
    except ValueError as exc:
        emit(1, str(exc))
    if not target.password and not target.private_key:
        emit(1, "缺少 SSH 凭证（PATROL_SSH_PASSWORD 或密钥），请检查 server_instance 配置")
    return target


def connect_ssh(target: SshTarget) -> paramiko.SSHClient:
    # 复用平台统一建连（含 Cisco 2960 短算法列表）；勿直接 client.connect
    from agent.utils.ssh_connection_util import connect_ssh_client

    return connect_ssh_client(
        host=target.host,
        port=target.port,
        username=target.username,
        password=target.password,
        private_key_content=target.private_key,
        timeout=int(os.environ.get("PATROL_SSH_TIMEOUT") or 30),
    )


def _strip_ansi(text: str) -> str:
    return re.sub(r"\x1b\[[0-9;?]*[ -/]*[@-~]", "", text)


def run_cli_command(
    shell: paramiko.Channel,
    command: str,
    timeout: float = 45.0,
    quiet: bool = False,
) -> str:
    """在交互式 shell 中执行单条只读命令，自动处理分页。"""
    shell.send(command + "\n")
    deadline = time.time() + timeout
    chunks: list[str] = []
    idle_rounds = 0

    while time.time() < deadline:
        if shell.recv_ready():
            raw = shell.recv(65535).decode("utf-8", errors="replace")
            chunks.append(raw)
            idle_rounds = 0
            cleaned = _strip_ansi(raw)
            if "--More--" in cleaned or "---- More ----" in cleaned or "-- more --" in cleaned.lower():
                shell.send(" ")
                continue
            if re.search(r"[>#]\s*$", cleaned.splitlines()[-1] if cleaned.splitlines() else ""):
                break
        else:
            idle_rounds += 1
            if idle_rounds >= 15 and chunks:
                break
            time.sleep(0.2)

    output = _strip_ansi("".join(chunks))
    lines = output.splitlines()
    result_lines: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped == command.strip():
            continue
        if stripped.endswith(command.strip()) and stripped.startswith(command.strip()):
            continue
        if re.match(r"^[<\[].+[>\]]$", stripped):
            continue
        if "--More--" in stripped or "---- More ----" in stripped:
            continue
        result_lines.append(line)
    return "\n".join(result_lines).strip()


def open_shell(client: paramiko.SSHClient) -> paramiko.Channel:
    shell = client.invoke_shell(term="vt100", width=200, height=50)
    time.sleep(0.8)
    if shell.recv_ready():
        shell.recv(65535)
    return shell


def detect_vendor_from_text(text: str) -> str | None:
    lowered = text.lower()
    if any(token in lowered for token in ("huawei", "vrp", "versatile routing platform")):
        return "huawei"
    if any(token in lowered for token in ("h3c", "comware", "new h3c")):
        return "h3c"
    if any(token in lowered for token in ("cisco", "ios-xe", "ios xe", "nx-os", "catalyst")):
        return "cisco"
    if "ruijie" in lowered or "rgos" in lowered:
        return "ruijie"
    return None


def resolve_vendor(requested: str, version_text: str) -> str:
    normalized = (requested or "auto").strip().lower()
    alias_map = {
        "huawei": "huawei",
        "hw": "huawei",
        "华为": "huawei",
        "h3c": "h3c",
        "hp": "h3c",
        "新华三": "h3c",
        "cisco": "cisco",
        "思科": "cisco",
        "ios": "cisco",
    }
    if normalized != "auto":
        resolved = alias_map.get(normalized, normalized)
        if resolved not in {"huawei", "h3c", "cisco"}:
            emit(
                1,
                f"不支持的厂商 `{requested}`，v1 支持 huawei / h3c / cisco，"
                "请通过 extra_args 传入正确 vendor",
            )
        return resolved

    detected = detect_vendor_from_text(version_text)
    if not detected or detected not in {"huawei", "h3c", "cisco"}:
        emit(
            1,
            "无法自动识别设备厂商，请在 extra_args 中显式传入 vendor（huawei / h3c / cisco）",
        )
    return detected


def get_driver(vendor: str) -> VendorDriver:
    from vendors import DRIVER_REGISTRY

    driver = DRIVER_REGISTRY.get(vendor)
    if not driver:
        emit(1, f"未找到厂商驱动: {vendor}")
    return driver


def parse_percent(value: str) -> int | None:
    match = re.search(r"(\d+(?:\.\d+)?)\s*%", value)
    if match:
        return int(float(match.group(1)))
    match = re.search(r"(\d+(?:\.\d+)?)", value)
    if match:
        return int(float(match.group(1)))
    return None


def severity_max(items: list[str]) -> str:
    if "CRIT" in items:
        return "CRIT"
    if "WARN" in items:
        return "WARN"
    return "OK"


def evaluate_metrics(metrics: dict[str, Any], thresholds: Thresholds, quick: bool = False) -> dict[str, Any]:
    findings: list[dict[str, str]] = []

    cpu = metrics.get("cpu_usage_pct")
    if cpu is not None:
        if cpu >= thresholds.cpu_crit:
            findings.append({
                "level": "CRIT",
                "item": "cpu",
                "message": f"CPU 使用率 {cpu}% >= {thresholds.cpu_crit}%",
            })
        elif cpu >= thresholds.cpu_warn:
            findings.append({
                "level": "WARN",
                "item": "cpu",
                "message": f"CPU 使用率 {cpu}% >= {thresholds.cpu_warn}%",
            })

    mem = metrics.get("memory_usage_pct")
    if mem is not None:
        if mem >= thresholds.mem_crit:
            findings.append({
                "level": "CRIT",
                "item": "memory",
                "message": f"内存使用率 {mem}% >= {thresholds.mem_crit}%",
            })
        elif mem >= thresholds.mem_warn:
            findings.append({
                "level": "WARN",
                "item": "memory",
                "message": f"内存使用率 {mem}% >= {thresholds.mem_warn}%",
            })

    iface = metrics.get("interfaces", {})
    down_count = iface.get("down", 0)
    if down_count >= thresholds.iface_down_warn:
        findings.append({
            "level": "WARN",
            "item": "interface",
            "message": f"存在 {down_count} 个 down 接口（阈值 {thresholds.iface_down_warn}）",
        })

    if not quick:
        alarms = metrics.get("alarms", [])
        if alarms:
            findings.append({
                "level": "WARN",
                "item": "alarm",
                "message": f"存在 {len(alarms)} 条活跃告警",
            })

        fans = metrics.get("fans", {})
        if fans.get("abnormal", 0) > 0:
            findings.append({
                "level": "CRIT",
                "item": "fan",
                "message": f"风扇异常 {fans['abnormal']} 个",
            })

        power = metrics.get("power", {})
        if power.get("abnormal", 0) > 0:
            findings.append({
                "level": "CRIT",
                "item": "power",
                "message": f"电源模块异常 {power['abnormal']} 个",
            })

    overall = severity_max([item["level"] for item in findings] or ["OK"])
    return {"overall": overall, "findings": findings, "finding_count": len(findings)}
