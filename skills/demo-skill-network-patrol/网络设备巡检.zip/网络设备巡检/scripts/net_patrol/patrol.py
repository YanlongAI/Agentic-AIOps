#!/usr/bin/env python3
# Copyright (c) 2025-2026 炎龙智能 (Yanlong AI). All Rights Reserved.
# https://www.yanlong-ai.com

"""网络设备只读健康巡检（SSH CLI，厂商驱动）。"""

from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import (
    connect_ssh,
    emit,
    evaluate_metrics,
    get_driver,
    load_ssh_target,
    load_thresholds,
    open_shell,
    resolve_vendor,
    run_cli_command,
)
from vendors.cisco import CiscoDriver


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="网络设备只读巡检")
    parser.add_argument("action", choices=["check", "quick", "report"])
    parser.add_argument("--vendor", default="auto", help="设备厂商：huawei / h3c / cisco / auto")
    parser.add_argument("--enable-password", default=None, help="思科 enable 密码（可选）")
    parser.add_argument("--report-path", default="./reports", help="报告输出目录")
    parser.add_argument("--cpu-warn", default=None)
    parser.add_argument("--cpu-crit", default=None)
    parser.add_argument("--mem-warn", default=None)
    parser.add_argument("--mem-crit", default=None)
    parser.add_argument("--iface-down-warn", default=None)
    return parser.parse_args()


def apply_threshold_overrides(args: argparse.Namespace) -> None:
    mapping = {
        "cpu_warn": "PATROL_CPU_WARN",
        "cpu_crit": "PATROL_CPU_CRIT",
        "mem_warn": "PATROL_MEM_WARN",
        "mem_crit": "PATROL_MEM_CRIT",
        "iface_down_warn": "PATROL_IFACE_DOWN_WARN",
    }
    for attr, env_key in mapping.items():
        value = getattr(args, attr, None)
        if value is not None:
            os.environ[env_key] = str(value)


def get_vendor_driver(vendor: str, enable_password: str | None):
    if vendor == "cisco":
        return CiscoDriver(enable_password=enable_password)
    return get_driver(vendor)


def probe_version_text(shell, vendor_hint: str) -> str:
    """按厂商或自动模式获取版本文本，用于驱动选择。"""
    if vendor_hint in {"cisco"}:
        return run_cli_command(shell, "show version", timeout=25)
    if vendor_hint in {"huawei", "h3c"}:
        return run_cli_command(shell, "display version", timeout=25)

    display_text = run_cli_command(shell, "display version", timeout=20)
    if display_text and "invalid" not in display_text.lower():
        return display_text
    return run_cli_command(shell, "show version", timeout=25)


def collect_metrics(vendor: str, enable_password: str | None, quick: bool = False) -> dict:
    target = load_ssh_target()
    thresholds = load_thresholds()
    client = connect_ssh(target)
    shell = open_shell(client)

    try:
        vendor_hint = (vendor or "auto").strip().lower()
        version_probe = probe_version_text(shell, vendor_hint if vendor_hint != "auto" else "")
        resolved_vendor = resolve_vendor(vendor, version_probe)
        driver = get_vendor_driver(resolved_vendor, enable_password)
        driver.prepare_session(shell)

        metrics = driver.collect_quick(shell)
        if not quick:
            metrics = driver.collect_full(shell, metrics)

        evaluation = evaluate_metrics(metrics, thresholds, quick=quick)
        return {
            "target": {
                "name": target.name,
                "host": target.host,
                "port": target.port,
                "username": target.username,
            },
            "vendor": resolved_vendor,
            "metrics": metrics,
            "evaluation": evaluation,
            "thresholds": {
                "cpu_warn": thresholds.cpu_warn,
                "cpu_crit": thresholds.cpu_crit,
                "mem_warn": thresholds.mem_warn,
                "mem_crit": thresholds.mem_crit,
                "iface_down_warn": thresholds.iface_down_warn,
            },
        }
    finally:
        shell.close()
        client.close()


def build_markdown(payload: dict) -> str:
    target = payload["target"]
    metrics = payload["metrics"]
    evaluation = payload["evaluation"]
    vendor = payload["vendor"]
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    iface = metrics.get("interfaces", {})
    lines = [
        "# 网络设备巡检报告",
        "",
        f"- 生成时间：{now}",
        f"- 目标：{target['name']} ({target['username']}@{target['host']}:{target['port']})",
        f"- 厂商驱动：**{vendor}**",
        f"- 总体状态：**{evaluation['overall']}**",
        "",
        "## 设备信息",
        "",
        f"- 型号：{metrics.get('model', 'unknown')}",
        f"- 软件版本：{metrics.get('software_version', '-')}",
        f"- 运行时长：{metrics.get('uptime', '-')}",
        "",
        "## 资源使用",
        "",
        f"- CPU 使用率：{metrics.get('cpu_usage_pct', '-')} %",
        f"- 内存使用率：{metrics.get('memory_usage_pct', '-')} %",
        "",
        "## 接口状态",
        "",
        f"- up：{iface.get('up', 0)}，down：{iface.get('down', 0)}，合计：{iface.get('total', 0)}",
    ]

    down_list = iface.get("down_list") or metrics.get("down_interfaces") or []
    if down_list:
        lines.append("- down 接口：" + ", ".join(down_list))

    fans = metrics.get("fans") or {}
    power = metrics.get("power") or {}
    if fans or power:
        lines.extend([
            "",
            "## 硬件状态",
            "",
            f"- 风扇：normal {fans.get('normal', 0)}，abnormal {fans.get('abnormal', 0)}",
            f"- 电源：normal {power.get('normal', 0)}，abnormal {power.get('abnormal', 0)}",
        ])

    alarms = metrics.get("alarms") or []
    if alarms:
        lines.extend(["", "## 活跃告警 / 异常日志", ""])
        for alarm in alarms:
            lines.append(f"- {alarm}")

    partial_errors = metrics.get("partial_errors") or []
    if partial_errors:
        lines.extend(["", "## 部分采集失败", ""])
        for err in partial_errors:
            lines.append(f"- {err}")

    lines.extend(["", "## 风险项", ""])
    if evaluation["findings"]:
        for item in evaluation["findings"]:
            lines.append(f"- [{item['level']}] {item['message']}")
    else:
        lines.append("- 无 WARN/CRIT 项")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    apply_threshold_overrides(args)
    quick = args.action == "quick"

    try:
        payload = collect_metrics(
            vendor=args.vendor,
            enable_password=args.enable_password,
            quick=quick,
        )
    except Exception as exc:
        emit(1, f"巡检失败: {exc}")

    evaluation = payload["evaluation"]
    msg = (
        f"巡检完成（{payload['vendor']}），总体状态 {evaluation['overall']}，"
        f"发现 {evaluation['finding_count']} 项风险"
    )

    if args.action == "report":
        os.makedirs(args.report_path, exist_ok=True)
        filename = f"net-patrol-{payload['vendor']}-{datetime.now().strftime('%Y%m%d%H%M%S')}.md"
        full_path = os.path.join(args.report_path, filename)
        markdown = build_markdown(payload)
        with open(full_path, "w", encoding="utf-8") as handle:
            handle.write(markdown)
        payload["report"] = {
            "path": full_path,
            "size_bytes": os.path.getsize(full_path),
        }
        msg = f"报告已生成：{full_path}"

    code = 0 if evaluation["overall"] != "CRIT" else 1
    emit(code, msg, payload)


if __name__ == "__main__":
    main()
